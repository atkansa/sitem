<?php
// PHPMailer ve Exception sınıflarını dahil ediyoruz
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require '../vendor/autoload.php'; // Composer autoload dosyasını ekliyoruz

// Veritabanı bağlantısı
require '../config.php';

// Bugünün tarihini alıyoruz
$today = date('Y-m-d');

// Bitiş tarihi 1 ay sonra olan sözleşmeleri sorguluyoruz
$query = "SELECT * FROM sozlesmeler WHERE DATE(bitis_tarihi) = DATE_ADD(DATE(:today), INTERVAL 1 MONTH)";
$stmt = $pdo->prepare($query);
$stmt->execute(['today' => $today]);

$contracts = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Eğer sözleşmeler varsa, e-posta gönderelim
foreach ($contracts as $contract) {
    // PHPMailer objesini oluşturuyoruz
    $mail = new PHPMailer(true);

    try {
        // Mail sunucu ayarları
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';  // SMTP sunucu (Gmail örneği)
        $mail->SMTPAuth = true;
        $mail->Username = 'your_email@gmail.com';  // Giriş yapacağınız e-posta
        $mail->Password = 'your_email_password';  // E-posta şifreniz
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Gönderen ve alıcı ayarları
        $mail->setFrom('your_email@gmail.com', 'Sözleşme Uyarısı');
        $mail->addAddress('kullanici@example.com');  // Alıcının e-posta adresi

        // E-posta içeriği
        $mail->isHTML(true);
        $mail->Subject = 'Sözleşme Bitiş Tarihi Yaklaşıyor';
        $mail->Body    = "Merhaba,<br><br>Sözleşmeniz: <strong>" . htmlspecialchars($contract['ad']) . "</strong> bitiş tarihi yaklaşıyor. Lütfen sözleşmeyi kontrol edin.<br><br><strong>Başlangıç Tarihi:</strong> " . $contract['baslangic_tarihi'] . "<br><strong>Bitiş Tarihi:</strong> " . $contract['bitis_tarihi'];

        // E-posta gönder
        $mail->send();
        echo "E-posta gönderildi: " . htmlspecialchars($contract['ad']) . "\n";
    } catch (Exception $e) {
        echo "E-posta gönderilemedi. Hata: {$mail->ErrorInfo}\n";
    }
}
?>
