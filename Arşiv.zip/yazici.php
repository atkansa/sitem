<?php
require 'header.php';
require 'config.php';

// Sıralama ve arama verileri
$orderby = $_GET['orderby'] ?? 'created_at';
$order = $_GET['order'] ?? 'DESC';
$search = $_GET['search'] ?? '';

// Güvenli sıralama için izin verilen sütunlar
$allowed_orderby = ['id', 'yazici_adi', 'konum', 'ip_adresi', 'modeli', 'created_at'];
$orderby = in_array($orderby, $allowed_orderby) ? $orderby : 'created_at';
$order = strtoupper($order) === 'ASC' ? 'ASC' : 'DESC';

// Silme işlemi
if (isset($_GET['action'], $_GET['id']) && $_GET['action'] === 'delete') {
    $id = (int)$_GET['id'];
    $stmt = $pdo->prepare("DELETE FROM yazicilar WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: yazici.php");
    exit();
}

// Ekleme/Güncelleme işlemi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $yazici_adi = trim($_POST['yazici_adi']);
    $konum = trim($_POST['konum']);
    $ip_adresi = trim($_POST['ip_adresi']);
    $modeli = trim($_POST['modeli']);

    if (!empty($_POST['id'])) {
        $stmt = $pdo->prepare("UPDATE yazicilar SET yazici_adi = ?, konum = ?, ip_adresi = ?, modeli = ? WHERE id = ?");
        $stmt->execute([$yazici_adi, $konum, $ip_adresi, $modeli, $_POST['id']]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO yazicilar (yazici_adi, konum, ip_adresi, modeli) VALUES (?, ?, ?, ?)");
        $stmt->execute([$yazici_adi, $konum, $ip_adresi, $modeli]);
    }
    header("Location: yazici.php");
    exit();
}

// Listeleme işlemi (arama ve sıralama dahil)
$sql = "SELECT * FROM yazicilar 
        WHERE yazici_adi LIKE :search OR konum LIKE :search OR ip_adresi LIKE :search OR modeli LIKE :search 
        ORDER BY $orderby $order";

$stmt = $pdo->prepare($sql);
$stmt->execute(['search' => "%$search%"]);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold text-secondary"><i class="bi bi-printer"></i> Yazıcılar</h2>
    <button type="button" class="btn btn-success shadow-sm" data-bs-toggle="modal" data-bs-target="#yaziciModal">
        <i class="bi bi-plus-circle"></i> Yeni Ekle
    </button>
</div>

<!-- Arama Formu -->
<form method="get" class="mb-3 d-flex justify-content-end">
    <input type="text" name="search" class="form-control w-25 me-2" placeholder="Yazıcı ara..." value="<?= htmlspecialchars($search) ?>">
    <button class="btn btn-outline-secondary" type="submit">Ara</button>
</form>

<div class="table-responsive shadow rounded bg-white p-3">
    <table class="table table-hover align-middle mb-0">
        <thead class="table-light">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Yazıcı Adı</th>
                <th scope="col">Konum</th>

                <!-- IP Adresi sıralanabilir sütun -->
                <?php
                    $newOrder = ($orderby === 'ip_adresi' && $order === 'ASC') ? 'DESC' : 'ASC';
                ?>
                <th scope="col">
                    <a href="?orderby=ip_adresi&order=<?= $newOrder ?>&search=<?= urlencode($search) ?>" class="text-decoration-none text-dark">
                        IP Adresi
                        <?php if ($orderby === 'ip_adresi'): ?>
                            <?= $order === 'ASC' ? '↑' : '↓' ?>
                        <?php endif; ?>
                    </a>
                </th>

                <th scope="col">Modeli</th>
                <th scope="col">Tarih</th>
                <th scope="col" class="text-center">İşlem</th>
            </tr>
        </thead>
        <tbody>
        <?php if (count($items) > 0): ?>
            <?php foreach($items as $item): ?>
                <tr>
                    <th scope="row"><?= $item['id'] ?></th>
                    <td class="fw-semibold"><?= htmlspecialchars($item['yazici_adi']) ?></td>
                    <td><?= htmlspecialchars($item['konum']) ?></td>
                    <td><?= htmlspecialchars($item['ip_adresi']) ?></td>
                    <td><?= htmlspecialchars($item['modeli']) ?></td>
                    <td><?= date('d.m.Y H:i', strtotime($item['created_at'])) ?></td>
                    <td class="text-center">
                        <button type="button" class="btn btn-sm btn-outline-primary me-2" data-bs-toggle="modal" data-bs-target="#yaziciModal"
                            data-id="<?= $item['id'] ?>"
                            data-adi="<?= htmlspecialchars($item['yazici_adi'], ENT_QUOTES) ?>"
                            data-konum="<?= htmlspecialchars($item['konum'], ENT_QUOTES) ?>"
                            data-ip="<?= htmlspecialchars($item['ip_adresi'], ENT_QUOTES) ?>"
                            data-model="<?= htmlspecialchars($item['modeli'], ENT_QUOTES) ?>">
                            <i class="bi bi-pencil-square"></i>
                        </button>
                        <a href="?action=delete&id=<?= $item['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Silmek istediğinize emin misiniz?')" data-bs-toggle="tooltip" title="Sil">
                            <i class="bi bi-trash3"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="7" class="text-center text-muted py-4">Kayıtlı yazıcı bulunamadı.</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Modal -->
<div class="modal fade" id="yaziciModal" tabindex="-1" aria-labelledby="yaziciModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form method="post" class="modal-content shadow">
      <div class="modal-header bg-success text-white">
        <h5 class="modal-title" id="yaziciModalLabel"><i class="bi bi-plus-circle"></i> Yeni Yazıcı</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Kapat"></button>
      </div>
      <div class="modal-body">
          <input type="hidden" name="id" id="yazici-id">
          <div class="mb-3">
              <label class="form-label">Yazıcı Adı</label>
              <input type="text" name="yazici_adi" id="yazici-adi" class="form-control" required>
          </div>
          <div class="mb-3">
              <label class="form-label">Konum</label>
              <input type="text" name="konum" id="yazici-konum" class="form-control">
          </div>
          <div class="mb-3">
              <label class="form-label">IP Adresi</label>
              <input type="text" name="ip_adresi" id="yazici-ip" class="form-control" required>
          </div>
          <div class="mb-3">
              <label class="form-label">Modeli</label>
              <input type="text" name="modeli" id="yazici-model" class="form-control" required>
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
        <button type="submit" class="btn btn-success">Kaydet</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Modal açıldığında içerikleri doldur
var yaziciModal = document.getElementById('yaziciModal');
yaziciModal.addEventListener('show.bs.modal', function (event) {
  var button = event.relatedTarget;
  var id = button.getAttribute('data-id') || '';
  var adi = button.getAttribute('data-adi') || '';
  var konum = button.getAttribute('data-konum') || '';
  var ip = button.getAttribute('data-ip') || '';
  var model = button.getAttribute('data-model') || '';

  yaziciModal.querySelector('#yazici-id').value = id;
  yaziciModal.querySelector('#yazici-adi').value = adi;
  yaziciModal.querySelector('#yazici-konum').value = konum;
  yaziciModal.querySelector('#yazici-ip').value = ip;
  yaziciModal.querySelector('#yazici-model').value = model;

  var modalTitle = yaziciModal.querySelector('.modal-title');
  modalTitle.innerHTML = id ? '<i class="bi bi-pencil-square"></i> Yazıcı Düzenle' : '<i class="bi bi-plus-circle"></i> Yeni Yazıcı';
});
</script>

<?php require 'footer.php'; ?>
