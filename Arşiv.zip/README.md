# Otel Bilgi İşlem Yönetim Paneli

## Kurulum

1. `otel_db.sql` dosyasını MySQL'de çalıştırarak veritabanını oluşturun.
2. `config.php` dosyasındaki veritabanı bağlantı bilgilerini güncelleyin.
3. `uploads/` klasörüne yazma izni verin.
4. Web sunucunuzun kök dizinine dosyaları kopyalayın.
5. İlk kullanıcıyı eklemek için:
   ```php
   <?php
   require 'config.php';
   $password = password_hash('sifre', PASSWORD_DEFAULT);
   $pdo->prepare("INSERT INTO users (username, password) VALUES (?,?)")->execute(['admin', $password]);
   ?>
   ```
6. Tarayıcınızdan `login.php` sayfasına gidin.
