<?php
   require 'config.php';
   $password = password_hash('sifre', PASSWORD_DEFAULT);
   $pdo->prepare("INSERT INTO users (username, password) VALUES (?,?)")->execute(['admin', $password]);
   ?>