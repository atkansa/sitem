<?php
require 'header.php';
?>

<div class="container py-5">
  <!-- Hero Bölümü -->
  <div class=" mb-4 bg-light rounded-3 shadow-sm">
    <div class="container-fluid py-5 text-center">
      <!-- Logo -->
      <img src="images/logo.png" alt="Logo" class="mb-4" style="max-width: 350px; height: auto;">
      
      <h1 class="display-5 fw-bold">Hoşgeldiniz, <?= htmlspecialchars($_SESSION['user']); ?>!</h1>
      <p class="col-md-8 fs-4 mx-auto text-muted">
        Otel bilgi işlem yönetim paneline hoş geldiniz.
      </p>
    </div>
  </div>

  <!-- Kartlar Bölümü -->
  <div class="row row-cols-1 row-cols-md-2 g-4">
    <!-- Demirbaşlar Kartı -->
    <div class="col">
      <div class="card h-100 shadow-sm border-0">
        <div class="card-body d-flex flex-column align-items-center">
          <i class="bi bi-box-seam fs-1 text-success"></i>
          <h5 class="card-title mt-3">Demirbaşlar</h5>
          <p class="card-text text-center flex-grow-1">
            Yeni demirbaş ekleyin, düzenleyin veya silin.
          </p>
          <a href="demirbaslar.php" class="btn btn-success">Yönet</a>
        </div>
      </div>
    </div>

    <!-- Sözleşmeler Kartı -->
    <div class="col">
      <div class="card h-100 shadow-sm border-0">
        <div class="card-body d-flex flex-column align-items-center">
          <i class="bi bi-file-earmark-text fs-1 text-info"></i>
          <h5 class="card-title mt-3">Sözleşmeler</h5>
          <p class="card-text text-center flex-grow-1">
            Sözleşme dosyalarınızı ekleyin, güncelleyin veya silin.
          </p>
          <a href="sozlesmeler.php" class="btn btn-info">Yönet</a>
        </div>
      </div>
    </div>

    <!-- IP Adresleri Kartı -->
    <div class="col">
      <div class="card h-100 shadow-sm border-0">
        <div class="card-body d-flex flex-column align-items-center">
          <i class="bi bi-globe2 fs-1 text-warning"></i>
          <h5 class="card-title mt-3">IP Adresleri</h5>
          <p class="card-text text-center flex-grow-1">
            Ağ üzerindeki IP adreslerini yönetin ve görüntüleyin.
          </p>
          <a href="ip.php" class="btn btn-warning text-white">Yönet</a>
        </div>
      </div>
    </div>

    <!-- Yazıcı Listesi Kartı -->
    <div class="col">
      <div class="card h-100 shadow-sm border-0">
        <div class="card-body d-flex flex-column align-items-center">
          <i class="bi bi-printer fs-1 text-danger"></i>
          <h5 class="card-title mt-3">Yazıcı Listesi</h5>
          <p class="card-text text-center flex-grow-1">
            Kayıtlı yazıcıları ekleyin, düzenleyin veya kaldırın.
          </p>
          <a href="yazici.php" class="btn btn-danger">Yönet</a>
        </div>
      </div>
    </div>
  </div>
</div>

<?php require 'footer.php'; ?>
