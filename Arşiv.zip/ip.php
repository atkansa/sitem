<?php
require 'header.php';
require 'config.php';

// Silme işlemi
if (isset($_GET['action'], $_GET['id']) && $_GET['action'] === 'delete') {
    $id = (int)$_GET['id'];
    $stmt = $pdo->prepare("DELETE FROM ip_adresleri WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: ip.php");
    exit();
}

// Ekleme/Güncelleme işlemi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ip_adresi = trim($_POST['ip_adresi']);
    $aciklama = trim($_POST['aciklama']);
    $kullanici_adi = trim($_POST['kullanici_adi']);
    $sifre = trim($_POST['sifre']);

    if (!empty($_POST['id'])) {
        $stmt = $pdo->prepare("UPDATE ip_adresleri SET ip_adresi = ?, aciklama = ?, kullanici_adi = ?, sifre = ? WHERE id = ?");
        $stmt->execute([$ip_adresi, $aciklama, $kullanici_adi, $sifre, $_POST['id']]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO ip_adresleri (ip_adresi, aciklama, kullanici_adi, sifre) VALUES (?, ?, ?, ?)");
        $stmt->execute([$ip_adresi, $aciklama, $kullanici_adi, $sifre]);
    }
    header("Location: ip.php");
    exit();
}

// Verileri listeleme
$stmt = $pdo->query("SELECT * FROM ip_adresleri ORDER BY created_at DESC");
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold text-secondary"><i class="bi bi-globe"></i> IP Adresleri</h2>
    <button type="button" class="btn btn-success shadow-sm" data-bs-toggle="modal" data-bs-target="#ipModal">
        <i class="bi bi-plus-circle"></i> Yeni Ekle
    </button>
</div>

<div class="table-responsive shadow rounded bg-white p-3">
    <table class="table table-hover align-middle mb-0">
        <thead class="table-light">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Ad</th>
                <th scope="col">IP Adresi</th>
                <th scope="col">Kullanıcı Adı</th>
                <th scope="col">Şifre</th>
                <th scope="col" class="text-center">İşlem</th>
            </tr>
        </thead>
        <tbody>
        <?php if (count($items) > 0): ?>
            <?php foreach($items as $item): ?>
            <tr>
                <th scope="row"><?= $item['id'] ?></th>
                <td><?= htmlspecialchars($item['aciklama']) ?></td>
                <td class="fw-semibold"><?= htmlspecialchars($item['ip_adresi']) ?></td>
                <td><?= htmlspecialchars($item['kullanici_adi']) ?></td>
                <td><?= htmlspecialchars($item['sifre']) ?></td>
                <td class="text-center">
                    <button type="button" class="btn btn-sm btn-outline-primary me-2" data-bs-toggle="modal" data-bs-target="#ipModal"
                        data-id="<?= $item['id'] ?>"
                        data-ip="<?= htmlspecialchars($item['ip_adresi'], ENT_QUOTES) ?>"
                        data-aciklama="<?= htmlspecialchars($item['aciklama'], ENT_QUOTES) ?>"
                        data-kullaniciadi="<?= htmlspecialchars($item['kullanici_adi'], ENT_QUOTES) ?>"
                        data-sifre="<?= htmlspecialchars($item['sifre'], ENT_QUOTES) ?>">
                        <i class="bi bi-pencil-square"></i>
                    </button>
                    <a href="?action=delete&id=<?= $item['id'] ?>" class="btn btn-sm btn-outline-danger" data-delete="true" data-bs-toggle="tooltip" title="Sil">
                        <i class="bi bi-trash3"></i>
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="6" class="text-center text-muted py-4">Kayıtlı IP adresi bulunamadı.</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Modal -->
<div class="modal fade" id="ipModal" tabindex="-1" aria-labelledby="ipModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form method="post" class="modal-content shadow">
      <div class="modal-header bg-success text-white">
        <h5 class="modal-title" id="ipModalLabel"><i class="bi bi-plus-circle"></i> Yeni IP Adresi</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Kapat"></button>
      </div>
      <div class="modal-body">
          <input type="hidden" name="id" id="ip-id">

          <div class="mb-3">
              <label class="form-label">IP Adresi</label>
              <input type="text" name="ip_adresi" id="ip-adresi" class="form-control" required
                  pattern="^(\d{1,3}\.){3}\d{1,3}$"
                  title="Geçerli bir IP adresi giriniz (örn: 192.168.1.1)">
          </div>

          <div class="mb-3">
              <label class="form-label">Açıklama</label>
              <textarea name="aciklama" id="ip-aciklama" class="form-control" rows="2"></textarea>
          </div>

          <div class="mb-3">
              <label class="form-label">Kullanıcı Adı</label>
              <input type="text" name="kullanici_adi" id="ip-kullaniciadi" class="form-control">
          </div>

          <div class="mb-3">
              <label class="form-label">Şifre</label>
              <input type="text" name="sifre" id="ip-sifre" class="form-control">
          </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
        <button type="submit" class="btn btn-success">Kaydet</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
// Modal açıldığında içerikleri doldur
var ipModal = document.getElementById('ipModal');
ipModal.addEventListener('show.bs.modal', function (event) {
  var button = event.relatedTarget;
  var id = button.getAttribute('data-id') || '';
  var ip = button.getAttribute('data-ip') || '';
  var aciklama = button.getAttribute('data-aciklama') || '';
  var kullaniciadi = button.getAttribute('data-kullaniciadi') || '';
  var sifre = button.getAttribute('data-sifre') || '';

  ipModal.querySelector('#ip-id').value = id;
  ipModal.querySelector('#ip-adresi').value = ip;
  ipModal.querySelector('#ip-aciklama').value = aciklama;
  ipModal.querySelector('#ip-kullaniciadi').value = kullaniciadi;
  ipModal.querySelector('#ip-sifre').value = sifre;

  var modalTitle = ipModal.querySelector('.modal-title');
  modalTitle.innerHTML = id ? '<i class="bi bi-pencil-square"></i> IP Adresi Düzenle' : '<i class="bi bi-plus-circle"></i> Yeni IP Adresi';
});

// IP adresi inputuna sadece rakam ve nokta girilmesini sağla
var ipInput = document.getElementById('ip-adresi');
ipInput.addEventListener('input', function (e) {
    this.value = this.value.replace(/[^0-9.]/g, '');
});

// 🔒 Biometrik Doğrulama Fonksiyonları
async function biometricAuth() {
    if (!window.PublicKeyCredential) {
        alert("Tarayıcınız biyometrik doğrulamayı desteklemiyor.");
        return false;
    }

    try {
        const publicKey = {
            challenge: new Uint8Array(32),
            timeout: 60000,
            userVerification: "preferred"
        };
        const credential = await navigator.credentials.get({ publicKey });
        return credential !== null;
    } catch (err) {
        console.error(err);
        alert("Doğrulama başarısız: " + err.message);
        return false;
    }
}

// Silme işlemi için
document.querySelectorAll('a[data-delete="true"]').forEach(function(button) {
    button.addEventListener('click', async function(event) {
        event.preventDefault();
        const isOk = await biometricAuth();
        if (isOk) {
            window.location.href = button.href;
        } else {
            alert('İşlem iptal edildi.');
        }
    });
});

// Form kaydetme işlemi için
const form = document.querySelector('form.modal-content');
form.addEventListener('submit', async function(event) {
    if (!form.querySelector('#ip-id').value) {
        // Yeni kayıt ekleniyorsa doğrulama istemiyoruz
        return;
    }

    event.preventDefault();
    const isOk = await biometricAuth();
    if (isOk) {
        form.submit();
    } else {
        alert('İşlem iptal edildi.');
    }
});
</script>

<?php require 'footer.php'; ?>
