<?php
require 'header.php';
require 'config.php';

$uploadDir = 'uploads/';

// Silme işlemi
if (isset($_GET['action'], $_GET['id']) && $_GET['action'] === 'delete') {
    $id = (int)$_GET['id'];
    $stmtFile = $pdo->prepare("SELECT dosya_path FROM demirbaslar WHERE id = ?");
    $stmtFile->execute([$id]);
    $file = $stmtFile->fetchColumn();
    if ($file && file_exists($uploadDir . $file)) {
        unlink($uploadDir . $file);
    }
    $stmt = $pdo->prepare("DELETE FROM demirbaslar WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: demirbaslar.php");
    exit();
}

// Ekleme/Güncelleme işlemi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cihaz_turu = trim($_POST['cihaz_turu']);
    $cihaz_marka = trim($_POST['cihaz_marka']);
    $cihaz_model = trim($_POST['cihaz_model']);
    $seri_no = trim($_POST['seri_no']);
    $aciklama = trim($_POST['aciklama']);
    $dosya_path = $_POST['existing_file'] ?? '';

    if (!empty($_FILES['dosya']['name']) && $_FILES['dosya']['error'] === UPLOAD_ERR_OK) {
        $tmpName = $_FILES['dosya']['tmp_name'];
        $safeName = uniqid() . '-' . basename($_FILES['dosya']['name']);
        move_uploaded_file($tmpName, $uploadDir . $safeName);
        $dosya_path = $safeName;
    }

    if (!empty($_POST['id'])) {
        $stmt = $pdo->prepare("UPDATE demirbaslar SET cihaz_turu = ?, cihaz_marka = ?, cihaz_model = ?, seri_no = ?, aciklama = ?, dosya_path = ? WHERE id = ?");
        $stmt->execute([$cihaz_turu, $cihaz_marka, $cihaz_model, $seri_no, $aciklama, $dosya_path, $_POST['id']]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO demirbaslar (cihaz_turu, cihaz_marka, cihaz_model, seri_no, aciklama, dosya_path) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$cihaz_turu, $cihaz_marka, $cihaz_model, $seri_no, $aciklama, $dosya_path]);
    }
    header("Location: demirbaslar.php");
    exit();
}

$stmt = $pdo->query("SELECT * FROM demirbaslar ORDER BY created_at DESC");
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold text-secondary"><i class="bi bi-box-seam"></i> Demirbaşlar</h2>
    <button type="button" class="btn btn-success shadow-sm" data-bs-toggle="modal" data-bs-target="#demirbasModal">
        <i class="bi bi-plus-circle"></i> Yeni Ekle
    </button>
</div>

<div class="table-responsive shadow rounded bg-white p-3">
    <table class="table table-hover align-middle mb-0">
        <thead class="table-light">
            <tr>
                <th scope="col">#</th>
                <th scope="col">Cihaz Türü</th>
                <th scope="col">Cihaz Marka</th>
                <th scope="col">Cihaz Model</th>
                <th scope="col">Seri No</th>
                <th scope="col">Açıklama</th>
                <th scope="col">Dosya</th>
                <th scope="col">Tarih</th>
                <th scope="col" class="text-center">İşlem</th>
            </tr>
        </thead>
        <tbody>
        <?php if (count($items) > 0): ?>
            <?php foreach($items as $item): ?>
            <tr>
                <th scope="row"><?= $item['id'] ?></th>
                <td class="fw-semibold"><?= htmlspecialchars($item['cihaz_turu']) ?></td>
                <td><?= htmlspecialchars($item['cihaz_marka']) ?></td>
                <td><?= htmlspecialchars($item['cihaz_model']) ?></td>
                <td><?= htmlspecialchars($item['seri_no']) ?></td>
                <td><?= htmlspecialchars($item['aciklama']) ?></td>
                <td>
                    <?php if ($item['dosya_path']): ?>
                        <a href="<?= $uploadDir . htmlspecialchars($item['dosya_path']) ?>" target="_blank" class="text-decoration-none" data-bs-toggle="tooltip" title="Dosyayı görüntüle">
                            <i class="bi bi-file-earmark-text fs-5"></i>
                        </a>
                    <?php else: ?>
                        <span class="text-muted">-</span>
                    <?php endif; ?>
                </td>
                <td><?= date('d.m.Y H:i', strtotime($item['created_at'])) ?></td>
                <td class="text-center">
                    <button type="button" class="btn btn-sm btn-outline-primary me-2" data-bs-toggle="modal" data-bs-target="#demirbasModal"
                        data-id="<?= $item['id'] ?>"
                        data-cihaz_turu="<?= htmlspecialchars($item['cihaz_turu'], ENT_QUOTES) ?>"
                        data-cihaz_marka="<?= htmlspecialchars($item['cihaz_marka'], ENT_QUOTES) ?>"
                        data-cihaz_model="<?= htmlspecialchars($item['cihaz_model'], ENT_QUOTES) ?>"
                        data-seri_no="<?= htmlspecialchars($item['seri_no'], ENT_QUOTES) ?>"
                        data-aciklama="<?= htmlspecialchars($item['aciklama'], ENT_QUOTES) ?>"
                        data-dosya="<?= htmlspecialchars($item['dosya_path'], ENT_QUOTES) ?>">
                        <i class="bi bi-pencil-square"></i>
                    </button>
                    <a href="?action=delete&id=<?= $item['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Silmek istediğinize emin misiniz?')" data-bs-toggle="tooltip" title="Sil">
                        <i class="bi bi-trash3"></i>
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="9" class="text-center text-muted py-4">Kayıtlı demirbaş bulunamadı.</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Modal -->
<div class="modal fade" id="demirbasModal" tabindex="-1" aria-labelledby="demirbasModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form method="post" enctype="multipart/form-data" class="modal-content shadow">
      <div class="modal-header bg-success text-white">
        <h5 class="modal-title" id="demirbasModalLabel"><i class="bi bi-plus-circle"></i> Yeni Demirbaş</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Kapat"></button>
      </div>
      <div class="modal-body">
          <input type="hidden" name="id" id="demirbas-id">
          <input type="hidden" name="existing_file" id="demirbas-existing-file">

          <div class="mb-3">
              <label class="form-label">Cihaz Türü</label>
              <input type="text" name="cihaz_turu" id="demirbas-cihaz-turu" class="form-control" required>
          </div>
          <div class="mb-3">
              <label class="form-label">Cihaz Marka</label>
              <input type="text" name="cihaz_marka" id="demirbas-cihaz-marka" class="form-control" required>
          </div>
          <div class="mb-3">
              <label class="form-label">Cihaz Model</label>
              <input type="text" name="cihaz_model" id="demirbas-cihaz-model" class="form-control" required>
          </div>
          <div class="mb-3">
              <label class="form-label">Seri No</label>
              <input type="text" name="seri_no" id="demirbas-seri-no" class="form-control" required>
          </div>
          <div class="mb-3">
              <label class="form-label">Açıklama</label>
              <textarea name="aciklama" id="demirbas-aciklama" class="form-control" rows="3"></textarea>
          </div>
          <div class="mb-3">
              <label class="form-label">Dosya</label>
              <input type="file" name="dosya" class="form-control" id="demirbas-dosya">
              <div id="current-file" class="form-text text-muted mt-1"></div>
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
        <button type="submit" class="btn btn-success">Kaydet</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Modal açıldığında içerikleri doldur
var demirbasModal = document.getElementById('demirbasModal');
demirbasModal.addEventListener('show.bs.modal', function (event) {
  var button = event.relatedTarget;
  var id = button.getAttribute('data-id') || '';
  var cihaz_turu = button.getAttribute('data-cihaz_turu') || '';
  var cihaz_marka = button.getAttribute('data-cihaz_marka') || '';
  var cihaz_model = button.getAttribute('data-cihaz_model') || '';
  var seri_no = button.getAttribute('data-seri_no') || '';
  var aciklama = button.getAttribute('data-aciklama') || '';
  var dosya = button.getAttribute('data-dosya') || '';

  demirbasModal.querySelector('#demirbas-id').value = id;
  demirbasModal.querySelector('#demirbas-cihaz-turu').value = cihaz_turu;
  demirbasModal.querySelector('#demirbas-cihaz-marka').value = cihaz_marka;
  demirbasModal.querySelector('#demirbas-cihaz-model').value = cihaz_model;
  demirbasModal.querySelector('#demirbas-seri-no').value = seri_no;
  demirbasModal.querySelector('#demirbas-aciklama').value = aciklama;
  demirbasModal.querySelector('#demirbas-existing-file').value = dosya;
  document.getElementById("current-file").innerHTML = dosya ? 'Mevcut Dosya: ' + dosya : 'Dosya yok';
});
</script>
