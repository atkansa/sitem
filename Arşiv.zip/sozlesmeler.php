<?php
require 'header.php';
require 'config.php';

$uploadDir = 'uploads/';

// Silme işlemi
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmtFile = $pdo->prepare("SELECT dosya_path FROM sozlesmeler WHERE id = ?");
    $stmtFile->execute([$id]);
    $file = $stmtFile->fetchColumn();
    if ($file && file_exists($uploadDir . $file)) {
        unlink($uploadDir . $file);
    }
    $stmt = $pdo->prepare("DELETE FROM sozlesmeler WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: sozlesmeler.php");
    exit();
}

// Ekleme/Güncelleme işlemi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ad = $_POST['ad'];
    $aciklama = $_POST['aciklama'];
    $baslangic_tarihi = $_POST['baslangic_tarihi'];
    $bitis_tarihi = $_POST['bitis_tarihi'];
    $dosya_path = $_POST['existing_file'] ?? '';

    if (isset($_FILES['dosya']) && $_FILES['dosya']['error'] === UPLOAD_ERR_OK) {
        $tmpName = $_FILES['dosya']['tmp_name'];
        $name = time() . '_' . basename($_FILES['dosya']['name']);
        move_uploaded_file($tmpName, $uploadDir . $name);
        $dosya_path = $name;
    }

    if (!empty($_POST['id'])) {
        $stmt = $pdo->prepare("UPDATE sozlesmeler SET ad = ?, aciklama = ?, baslangic_tarihi = ?, bitis_tarihi = ?, dosya_path = ? WHERE id = ?");
        $stmt->execute([$ad, $aciklama, $baslangic_tarihi, $bitis_tarihi, $dosya_path, $_POST['id']]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO sozlesmeler (ad, aciklama, baslangic_tarihi, bitis_tarihi, dosya_path) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$ad, $aciklama, $baslangic_tarihi, $bitis_tarihi, $dosya_path]);
    }
    header("Location: sozlesmeler.php");
    exit();
}

$stmt = $pdo->query("SELECT * FROM sozlesmeler ORDER BY created_at DESC");
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold text-secondary"><i class="bi bi-file-earmark-text"></i> Sözleşmeler</h2>
    <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modal">
        <i class="bi bi-plus-circle"></i> Yeni Sözleşme
    </button>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <input type="text" id="searchInput" class="form-control mb-3" placeholder="Sözleşme adı veya açıklama ara...">

        <div class="table-responsive">
            <table class="table table-hover align-middle" id="sozlesmeTable">
                <thead class="table-secondary">
                    <tr>
                        <th>ID</th>
                        <th>Ad</th>
                        <th>Açıklama</th>
                        <th>Başlangıç Tarihi</th>
                        <th>Bitiş Tarihi</th>
                        <th>Dosya</th>
                        <th>Tarih</th>
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach($items as $item): ?>
                    <tr>
                        <td><?= $item['id'] ?></td>
                        <td><?= htmlspecialchars($item['ad']) ?></td>
                        <td><?= htmlspecialchars($item['aciklama']) ?></td>
                        <td><?= date('d.m.Y', strtotime($item['baslangic_tarihi'])) ?></td>
                        <td><?= date('d.m.Y', strtotime($item['bitis_tarihi'])) ?></td>
                        <td>
                            <?php if ($item['dosya_path']): ?>
                                <a href="<?= $uploadDir . htmlspecialchars($item['dosya_path']) ?>" target="_blank" class="btn btn-sm btn-outline-secondary">
                                    <i class="bi bi-file-earmark-pdf"></i> Görüntüle
                                </a>
                            <?php else: ?>
                                <span class="text-muted">Yok</span>
                            <?php endif; ?>
                        </td>
                        <td><?= date('d.m.Y H:i', strtotime($item['created_at'])) ?></td>
                        <td>
                            <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#modal"
                                data-id="<?= $item['id'] ?>"
                                data-ad="<?= htmlspecialchars($item['ad'], ENT_QUOTES) ?>"
                                data-aciklama="<?= htmlspecialchars($item['aciklama'], ENT_QUOTES) ?>"
                                data-baslangic="<?= htmlspecialchars($item['baslangic_tarihi'], ENT_QUOTES) ?>"
                                data-bitis="<?= htmlspecialchars($item['bitis_tarihi'], ENT_QUOTES) ?>"
                                data-dosya="<?= htmlspecialchars($item['dosya_path'], ENT_QUOTES) ?>">
                                <i class="bi bi-pencil-square"></i>
                            </button>
                            <a href="?action=delete&id=<?= $item['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Bu sözleşmeyi silmek istediğinizden emin misiniz?')">
                                <i class="bi bi-trash"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="modal" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form method="post" enctype="multipart/form-data" class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title" id="modalLabel">Sözleşme Ekle</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Kapat"></button>
      </div>
      <div class="modal-body">
          <input type="hidden" name="id" id="id">
          <input type="hidden" name="existing_file" id="existing-file">
          <div class="mb-3">
              <label>Ad</label>
              <input type="text" name="ad" id="ad" class="form-control" required>
          </div>
          <div class="mb-3">
              <label>Açıklama</label>
              <textarea name="aciklama" id="aciklama" class="form-control" rows="3"></textarea>
          </div>
          <div class="mb-3">
              <label>Başlangıç Tarihi</label>
              <input type="date" name="baslangic_tarihi" id="baslangic_tarihi" class="form-control" required>
          </div>
          <div class="mb-3">
              <label>Bitiş Tarihi</label>
              <input type="date" name="bitis_tarihi" id="bitis_tarihi" class="form-control" required>
          </div>
          <div class="mb-3">
              <label>Dosya</label>
              <input type="file" name="dosya" class="form-control">
              <small id="current-file" class="form-text text-muted"></small>
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">İptal</button>
        <button type="submit" class="btn btn-success">Kaydet</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Modal içeriği doldurma
var modal = document.getElementById('modal')
modal.addEventListener('show.bs.modal', function (event) {
  var button = event.relatedTarget;
  var id = button.getAttribute('data-id');
  var ad = button.getAttribute('data-ad');
  var aciklama = button.getAttribute('data-aciklama');
  var baslangic = button.getAttribute('data-baslangic');
  var bitis = button.getAttribute('data-bitis');
  var dosya = button.getAttribute('data-dosya');

  var modalTitle = modal.querySelector('.modal-title');
  modalTitle.textContent = id ? 'Sözleşme Düzenle' : 'Sözleşme Ekle';

  modal.querySelector('#id').value = id || '';
  modal.querySelector('#ad').value = ad || '';
  modal.querySelector('#aciklama').value = aciklama || '';
  modal.querySelector('#baslangic_tarihi').value = baslangic || '';
  modal.querySelector('#bitis_tarihi').value = bitis || '';
  modal.querySelector('#existing-file').value = dosya || '';
  modal.querySelector('#current-file').textContent = dosya ? 'Mevcut dosya: ' + dosya : '';
})

// Arama filtreleme
document.getElementById('searchInput').addEventListener('keyup', function() {
    var value = this.value.toLowerCase();
    var rows = document.querySelectorAll("#sozlesmeTable tbody tr");
    rows.forEach(function(row) {
        var text = row.innerText.toLowerCase();
        row.style.display = text.includes(value) ? '' : 'none';
    });
});
</script>

<?php require 'footer.php'; ?>
