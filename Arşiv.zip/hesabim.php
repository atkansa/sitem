<?php
require 'header.php';
require 'config.php';

// Kullanıcının bilgilerini çek
$stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
$stmt->execute([$_SESSION['user']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo "Kullanıcı bulunamadı.";
    exit();
}

// Güncelleme işlemi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ad_soyad = trim($_POST['ad_soyad']);
    $email = trim($_POST['email']);
    $yeni_sifre = trim($_POST['yeni_sifre']);
    $mevcut_sifre = trim($_POST['mevcut_sifre']);
    $profil_foto = $_FILES['profil_photo']['name'];

    // Mevcut şifreyi kontrol et
    if (!empty($mevcut_sifre)) {
        if (!password_verify($mevcut_sifre, $user['password'])) {
            echo "Mevcut şifre yanlış.";
            exit();
        }
    }

    // Profil fotoğrafı işlemi
    if (!empty($profil_foto)) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($profil_foto);

        // Dosya uzantısını kontrol et
        $allowed_extensions = ['png', 'jpg', 'jpeg'];
        $file_extension = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        if (!in_array($file_extension, $allowed_extensions)) {
            echo "Geçersiz dosya formatı. Lütfen sadece PNG, JPG veya JPEG dosyası yükleyin.";
            exit();
        }

        // Fotoğrafı yükle
        if (move_uploaded_file($_FILES["profil_photo"]["tmp_name"], $target_file)) {
            // Fotoğraf başarıyla yüklendi
        } else {
            echo "Fotoğraf yüklenirken bir hata oluştu.";
            exit();
        }
    } else {
        // Eğer fotoğraf güncellenmemişse mevcut fotoğrafı kullan
        $target_file = $user['profil_photo'];
    }

    // Şifre değiştirilecekse
    if (!empty($yeni_sifre)) {
        $hashed_password = password_hash($yeni_sifre, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET ad_soyad = ?, email = ?, password = ?, profil_photo = ? WHERE username = ?");
        $stmt->execute([$ad_soyad, $email, $hashed_password, $target_file, $_SESSION['user']]);
    } else {
        // Şifre değiştirilmeyecekse
        $stmt = $pdo->prepare("UPDATE users SET ad_soyad = ?, email = ?, profil_photo = ? WHERE username = ?");
        $stmt->execute([$ad_soyad, $email, $target_file, $_SESSION['user']]);
    }

    header("Location: hesabim.php?success=1");
    exit();
}
?>

<div class="container mt-5">
    <h2 class="fw-bold text-secondary mb-4"><i class="bi bi-person-circle"></i> Hesabım</h2>

    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success">Bilgileriniz başarıyla güncellendi.</div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" class="shadow p-4 rounded bg-white">
        <div class="row mb-3">
            <div class="col-md-4">
                <label class="form-label">Ad Soyad</label>
                <input type="text" name="ad_soyad" class="form-control" value="<?= htmlspecialchars($user['ad_soyad']) ?>" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">E-posta</label>
                <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">Mevcut Şifre</label>
                <input type="password" name="mevcut_sifre" class="form-control" required>
            </div>
            <div class="col-md-4">
                <label class="form-label">Yeni Şifre (Değiştirmek istemiyorsanız boş bırakın)</label>
                <input type="password" name="yeni_sifre" class="form-control">
            </div>
        </div>

        <!-- Profil Fotoğrafı -->
        <div class="mb-3">
            <label class="form-label">Profil Fotoğrafı (Yeni fotoğraf yüklemek isterseniz, aşağıdan seçin)</label>
            <div class="d-flex align-items-center">
                <?php if ($user['profil_photo']): ?>
                    <img src="<?= $user['profil_photo'] ?>" alt="Profil Fotoğrafı" class="img-thumbnail" width="100">
                <?php else: ?>
                    <span>Profil fotoğrafı yok.</span>
                <?php endif; ?>
                <input type="file" name="profil_photo" class="form-control ms-3" id="profilPhotoInput">
            </div>
            <div id="error-message" class="text-danger mt-2" style="display:none;"></div>
        </div>

        <button type="submit" class="btn btn-success">Bilgileri Güncelle</button>
    </form>
</div>

<script>
    // Dosya seçildiğinde kontrol et
    document.getElementById('profilPhotoInput').addEventListener('change', function() {
        var file = this.files[0];
        var errorMessage = document.getElementById('error-message');
        
        if (file) {
            var fileExtension = file.name.split('.').pop().toLowerCase();
            var allowedExtensions = ['png', 'jpg', 'jpeg'];

            if (allowedExtensions.indexOf(fileExtension) === -1) {
                errorMessage.style.display = 'block';
                errorMessage.textContent = 'Geçersiz dosya formatı. Lütfen sadece PNG, JPG veya JPEG dosyası yükleyin.';
                this.value = ''; // Inputu temizle
            } else {
                errorMessage.style.display = 'none';
            }
        }
    });
</script>

<?php require 'footer.php'; ?>
