<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Otel Bilgi İşlem</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.5/font/bootstrap-icons.min.css">

    <style>
        body {
            background-color: #f8f9fa;
        }
        .navbar-brand {
            font-weight: bold;
            font-size: 1.5rem;
        }
        .logout-btn:hover {
            background-color: #fff;
            color: #0d6efd;
            border-color: #fff;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-secondary bg-secondary shadow-sm">
    <div class="container">
        <a class="navbar-brand text-white" href="index.php">
            <i class="bi bi-building"></i> Bilgi İşlem
        </a>
        
        <div class="d-flex">
        <a href="hesabim.php" class="btn btn-outline-light logout-btn">
        <i class="bi bi-person-circle"></i> Hesabım
            </a>
            <a href="http://localhost/logout.php" class="btn btn-outline-light logout-btn">
                <i class="bi bi-box-arrow-right"></i> Çıkış Yap
            </a>
        </div>
    </div>
</nav>

<div class="container mt-5">
